#ifndef _COMMANDER_HPP
#define _COMMANDER_HPP
#include "Board.hpp"

namespace WarGame {

    template <class T>
    class Commander
    {
        
        public:
            void command(Board& board);
           
    };

}
#endif